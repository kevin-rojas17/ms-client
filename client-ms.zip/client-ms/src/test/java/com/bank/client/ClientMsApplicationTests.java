package com.bank.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
